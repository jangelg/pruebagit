package Modelo;

public class Canino extends Mamifero {

	
	
	
	public Canino(String raza, int numpatas) 
	{
		super.raza="french poodle";
		super.numeropatas=numpatas;
		
	}
	@Override
	public void alimentar() {
		// TODO Auto-generated method stub
		System.out.print("como concentrado,shhh");
	}

	@Override
	public void hacersonido() {
		// TODO Auto-generated method stub
		System.out.println("guauuuuuu, guauuuu");
	}

}
