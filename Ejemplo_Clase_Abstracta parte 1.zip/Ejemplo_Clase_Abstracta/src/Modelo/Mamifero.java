package Modelo;

public abstract class Mamifero {

	protected String raza;
	protected int numeropatas;
	
	public abstract void alimentar() ;
	public abstract void hacersonido();
		
	
	
}
