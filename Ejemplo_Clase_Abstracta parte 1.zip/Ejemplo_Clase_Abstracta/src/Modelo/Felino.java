package Modelo;

public class Felino extends Mamifero {

	public Felino(String raza, int numpatas) 
	{
		super.raza="french poodle";
		super.numeropatas=numpatas;
		
	}
	@Override
	public void alimentar() {
		// TODO Auto-generated method stub
		System.out.println("como carne,yummy yummy");
	}

	@Override
	public void hacersonido() {
		// TODO Auto-generated method stub
		System.out.println("mmiauuuu o depende");
	}

}
