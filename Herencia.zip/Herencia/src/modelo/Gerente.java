package modelo;

public class Gerente extends Empleado{
	private int personaCargo;
public Gerente(String nombre, int edad) 
{
	super(nombre,edad);
	this.personaCargo=personaCargo;
}
public void echar() 
{
	System.out.println(" Usted ha sido despedido "+ personaCargo);
}
public int getpersonaCargo() {
	return personaCargo;
}
public void setpersonaCargo(int personaCargo){
	this.personaCargo=personaCargo;

}

}

