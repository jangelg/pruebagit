package modelo;

public class Empleado extends Persona{
private double salario;
private String cargo;
public Empleado( String nombre,int edad) {
	super(nombre,edad);
	this.salario = 0;
	this.cargo = "delantero";
}
public double getSalario() {
	return salario;
}
public void setSalario(double salario) {
	this.salario = salario;
}
public String getCargo() {
	return cargo;
}
public void setCargo(String cargo) {
	this.cargo = cargo;
}
public void Cobrar() 
{}
public void correr() {
	// TODO Auto-generated method stub
	System.out.println("yo me llamo "+super.nombre);
}
public void cobrar() {
	// TODO Auto-generated method stub
	
}
}
