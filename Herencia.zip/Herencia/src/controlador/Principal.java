package controlador;

import modelo.Empleado;
import modelo.Gerente;

public class Principal {
	private static Empleado emp1;
	private static Gerente ger1;
public static void main(String[] args) {
	emp1=new Empleado("Gareth Bale",1234);
	
	emp1.correr();
	emp1.cobrar();
	ger1=new Gerente("cristiano ronaldo",1);
	ger1.echar();
	ger1.setpersonaCargo(12);
}
}
